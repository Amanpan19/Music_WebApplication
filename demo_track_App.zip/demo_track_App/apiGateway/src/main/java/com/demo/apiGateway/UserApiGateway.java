package com.demo.apiGateway;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;



@Configuration
public class UserApiGateway {

    @Bean
    public RouteLocator routeUrl(RouteLocatorBuilder routeLocatorBuilder){
        return routeLocatorBuilder.routes()
                .route(p->p.path("/api/authApp/**")
                        .uri("http://localhost:9000"))
                .route(p->p.path("/api/userService/**")
                        .uri("http://localhost:8090"))
                .build();
    }

}
