package com.demo.authApplication.controller;

import com.demo.authApplication.domain.User;
import com.demo.authApplication.domain.UserDto;
import com.demo.authApplication.service.ITokenGenerator;
import com.demo.authApplication.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/authApp")
public class UserController {
    private IUserService iUserService;
    private ITokenGenerator iTokenGenerator;
    @Autowired
    public UserController(IUserService iUserService, ITokenGenerator iTokenGenerator) {
        this.iUserService = iUserService;
        this.iTokenGenerator = iTokenGenerator;
    }

    // http://localhost:9000/api/authApp/register
    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody UserDto userDto){
        User user = new User(userDto.getEmail(), userDto.getPassword(), userDto.getRole(), userDto.getName());
        return new ResponseEntity<>(iUserService.register(user), HttpStatus.CREATED);
    }

    // http://localhost:9000/api/authApp/login
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User user){
        User retrievedUser = iUserService.login(user);
        if(retrievedUser!=null){
            return new ResponseEntity<>(iTokenGenerator.tokenGeneration(retrievedUser),HttpStatus.ACCEPTED);
        }
        else {
            return new ResponseEntity<>("Authentication Failed.....",HttpStatus.NOT_FOUND);
        }
    }
}
