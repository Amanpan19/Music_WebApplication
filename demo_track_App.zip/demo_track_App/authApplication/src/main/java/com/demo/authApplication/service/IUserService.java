package com.demo.authApplication.service;

import com.demo.authApplication.domain.User;

public interface IUserService {
    public User login (User user);
    public User register (User user);
}
