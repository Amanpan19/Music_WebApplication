package com.demo.authApplication.service;

import com.demo.authApplication.domain.User;

import java.util.Map;

public interface ITokenGenerator {
    public Map<String,String> tokenGeneration(User user);
}
