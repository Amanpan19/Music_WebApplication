package com.demo.authApplication.service;

import com.demo.authApplication.domain.User;
import com.demo.authApplication.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService implements IUserService{
    private UserRepo userRepo;

    @Autowired
    public UserService(UserRepo userRepo) {
        this.userRepo = userRepo;
    }

    @Override
    public User login(User user) {
        return userRepo.findByEmailAndPassword(user.getEmail(), user.getPassword());
    }

    @Override
    public User register(User user) {
        System.out.println(user);
        return userRepo.save(user);
    }
}
