package com.project.songs.service;

import com.project.songs.domain.Songs;
import com.project.songs.repository.SongRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SongService implements ISongService{
    private SongRepo songRepo;
    @Autowired
    public SongService(SongRepo songRepo) {
        this.songRepo = songRepo;
    }

    @Override
    public List<Songs> getAllSongs() {
        return songRepo.findAll();
    }

    @Override
    public Songs addSong(Songs song) {
        return songRepo.save(song);
    }

    @Override
    public Songs getSongById(String songName) {
        return songRepo.findById(songName).get();
    }
}
