package com.project.songs.controller;

import com.project.songs.domain.Songs;
import com.project.songs.service.ISongService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/songs/list")
public class SongController {
    private ISongService iSongService;

    @Autowired
    public SongController(ISongService iSongService) {
        this.iSongService = iSongService;
    }

    // http://localhost:6262/songs/list/get/all-songs
    @GetMapping("/get/all-songs")
    public ResponseEntity<?> getAllSongs(){
        return new ResponseEntity<>(iSongService.getAllSongs(), HttpStatus.OK);
    }
    // http://localhost:6262/songs/list/addSong
    @PostMapping("/addSong")
    public ResponseEntity<?> addSong(@RequestBody Songs song){
        return new ResponseEntity<>(iSongService.addSong(song),HttpStatus.CREATED);
    }

    //http://localhost:6262/songs/list/songBy/{id}
    @GetMapping("/songBy/{id}")
    public ResponseEntity<?> getSongById(@PathVariable String id){
        return new ResponseEntity<>(iSongService.getSongById(id),HttpStatus.OK);
    }
}
