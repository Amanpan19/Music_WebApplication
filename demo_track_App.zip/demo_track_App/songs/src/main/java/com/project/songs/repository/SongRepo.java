package com.project.songs.repository;

import com.project.songs.domain.Songs;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface SongRepo extends MongoRepository<Songs,String> {

}
