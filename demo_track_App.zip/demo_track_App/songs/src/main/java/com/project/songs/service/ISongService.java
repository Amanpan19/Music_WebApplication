package com.project.songs.service;

import com.project.songs.domain.Songs;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ISongService {
    public List<Songs> getAllSongs();
    public Songs addSong(Songs song);
    public Songs getSongById(String songName);
}
