package com.connnect.connectivity.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.io.Serializable;
import java.util.List;

@Document
@AllArgsConstructor
@NoArgsConstructor
@Data
// Serialization in Java allows us to convert an Object to stream that we can send
// over the network or save it as file or store in DB for later usage.
public class User implements Serializable {
    @Id
    private String email;
    private String password;
    private String name;
    private String role = "user";
    private List<Playlist> playlists;
}
