package com.connnect.connectivity.service;

import com.connnect.connectivity.domain.Playlist;
import com.connnect.connectivity.domain.Songs;
import com.connnect.connectivity.domain.User;
import com.connnect.connectivity.domain.UserDto;
import com.connnect.connectivity.proxy.UserProxy;
import com.connnect.connectivity.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserService implements IUserService{
    private UserRepository userRepository;
    private UserProxy userProxy;

    @Autowired
    public UserService(UserRepository userRepository, UserProxy userProxy) {
        this.userRepository = userRepository;
        this.userProxy = userProxy;
    }

    @Override
    public User saveUser(User user) {
        UserDto userDto = new UserDto();

        userDto.setEmail(user.getEmail());
        userDto.setPassword(user.getPassword());
        userDto.setRole(user.getRole());
        userDto.setName(user.getName());

        userProxy.registerUser(userDto);

        return userRepository.save(user);
    }

    @Override
    public List<User> getUser() {
        return userRepository.findAll();
    }

    @Override
    public void deletePlaylistByPlaylistId(String email,String playlistName) {
        User user = userRepository.findById(email).get();
        List<Playlist> userPlaylist = user.getPlaylists();
        for(Playlist p: userPlaylist) {
            if (p.getPlaylistName().equals(playlistName)) {
                userPlaylist.remove(p);
                System.out.println(playlistName);
                userRepository.save(user);
                break;
            }
        }
    }

    @Override
    public User addPlayList(String email, Playlist playlist) {
        User user = userRepository.findById(email).get();
        // to check whether this playlist exists or not.
        boolean playlistExists = false;
        if (user.getPlaylists() != null) {
            for (Playlist list : user.getPlaylists()) {
                if (list.getPlaylistName().equals(playlist.getPlaylistName())) {

                    list.getSongList().add(playlist.getSongList().get(0));
                    playlistExists = true;
                    break;
                }
            }
        }
        if (!playlistExists) {
            if (user.getPlaylists() == null) {
                user.setPlaylists(new ArrayList<>());
            }
            user.getPlaylists().add(playlist);
        }
        userRepository.save(user);
        return user;
    }

    @Override
    public List<Playlist> getPlaylistByEmail(String email) {
        User user = userRepository.findById(email).get();
        List<Playlist>playlistsAvailable = user.getPlaylists();
        if(playlistsAvailable!=null){
            userRepository.findAll();
        }
        return playlistsAvailable;
    }


    @Override
    public User getUserNameById(String email) {
        User user = userRepository.findById(email).get();
        return user;
    }

    @Override
    public List<Songs> getSongsByPlaylistId(String email, String playlistName) {
        System.out.println(email);
        List<Playlist> userPlaylist = userRepository.findById(email).get().getPlaylists();
        if(userPlaylist!=null) {
            for (Playlist playlist : userPlaylist) {
                if (playlist.getPlaylistName().equals(playlistName)) {
                    return playlist.getSongList();
                }
            }
        }
        return null;
    }
}
