package com.connnect.connectivity.proxy;

import com.connnect.connectivity.domain.UserDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

// synchronous communication
@FeignClient(name="authService",url="http://localhost:9000")
public interface UserProxy {
    @PostMapping("/api/authApp/register")
    public ResponseEntity<?> registerUser(@RequestBody UserDto userDto);
}
