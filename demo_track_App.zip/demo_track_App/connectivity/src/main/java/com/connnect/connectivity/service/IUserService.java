package com.connnect.connectivity.service;

import com.connnect.connectivity.domain.Playlist;
import com.connnect.connectivity.domain.Songs;
import com.connnect.connectivity.domain.User;

import java.util.List;

public interface IUserService {
    public User saveUser(User user);
    public List<User> getUser();
    public void deletePlaylistByPlaylistId(String email,String playlistName);
    public User addPlayList(String email, Playlist playlist);
    public List<Playlist> getPlaylistByEmail(String email);
    public User getUserNameById(String email);
    public List<Songs> getSongsByPlaylistId(String email,String playlistName);
}
