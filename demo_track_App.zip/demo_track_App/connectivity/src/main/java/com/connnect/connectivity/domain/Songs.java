package com.connnect.connectivity.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Songs {
    @Id
    private String songName;
    private String artistName;
    private String rating;
}
