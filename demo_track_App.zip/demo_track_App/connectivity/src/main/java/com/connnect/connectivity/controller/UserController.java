package com.connnect.connectivity.controller;

import com.connnect.connectivity.domain.Playlist;
import com.connnect.connectivity.domain.User;
import com.connnect.connectivity.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/userService")
public class UserController {
    @Autowired
    private IUserService iUserService;

    // http://localhost:8090/api/userService/add-user
    @PostMapping("/add-user")
    public ResponseEntity<?> addUser(@RequestBody User user){
        return new ResponseEntity<>(iUserService.saveUser(user), HttpStatus.CREATED);
    }

    // http://localhost:8090/api/userService/get/Users
    @GetMapping("/get/Users")
    public ResponseEntity<?> getListOfUsers(HttpServletRequest request){
        if(request.getAttribute("attr2").equals("admin")){
            return new ResponseEntity<>(iUserService.getUser(),HttpStatus.OK);
        }
        else {
            return new ResponseEntity<>("You are Not authorized to get track list",HttpStatus.BAD_REQUEST);
        }
    }


    // http://localhost:8090/api/userService/add/Playlist
    @PostMapping("/add/Playlist")
    public ResponseEntity<?> addPlaylist(HttpServletRequest httpServletRequest,@RequestBody Playlist playlist){
        String email =(String) httpServletRequest.getAttribute("attr1");
        System.out.println(email);
        return new ResponseEntity<>(iUserService.addPlayList(email,playlist),HttpStatus.OK);
    }

    // http://localhost:8090/api/userService/delete/playlist/{id}
    @DeleteMapping("/delete/playlist")
    public ResponseEntity<?> removeUser(HttpServletRequest httpServletRequest,@RequestParam String playlistName){
        String email= (String)httpServletRequest.getAttribute("attr1");
        System.out.println("deleted");
        iUserService.deletePlaylistByPlaylistId(email,playlistName);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    // http://localhost:8090/api/userService/get/playlist
    @GetMapping("/get/playlist")
    public ResponseEntity<?> getPlaylists(HttpServletRequest httpServletRequest){
        String email=(String) httpServletRequest.getAttribute("attr1");
        System.out.println(email);
        iUserService.getPlaylistByEmail(email);
        return new ResponseEntity<>(iUserService.getPlaylistByEmail(email),HttpStatus.OK);
    }

    //http://localhost:8090/api/userService/get/name
    @GetMapping("/get/name")
    public ResponseEntity getName(HttpServletRequest request){
        String email = (String)request.getAttribute("attr1");
        return new ResponseEntity(iUserService.getUserNameById(email),HttpStatus.OK);
    }

    //http://localhost:8090/api/userService/get/songList/{playlistName}

    @PostMapping("/get/songList")
    public ResponseEntity<?> getSongListByPlaylistName(HttpServletRequest request, @RequestParam String playlistName){
        String email = (String)request.getAttribute("attr1");
        System.out.println(email);
        System.out.println(playlistName);
        return new ResponseEntity(iUserService.getSongsByPlaylistId(email,playlistName),HttpStatus.OK);
    }

}
